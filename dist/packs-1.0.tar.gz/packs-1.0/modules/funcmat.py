def suma(a, b):
    print("La suma es: ", a + b)


def resta(a, b):
    print("La resta es: ", a + b)


def multiplicacion(a, b):
    print("La multiplicacion es: ", a * b)


def division(a, b):
    print("La division es: ", a / b)