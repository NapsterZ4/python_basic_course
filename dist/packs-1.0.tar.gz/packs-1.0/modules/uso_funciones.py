import modules.funcmat as sm
from modules.funcmat import multiplicacion as mtp


sm.suma(5,6)
sm.multiplicacion(45,6)
sm.resta(6,2)
sm.division(60, 45)

mtp(45,67)