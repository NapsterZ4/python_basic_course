from setuptools import setup

setup(
    name="packs",
    version="1.0",
    description="Operaciones matematicas basicas",
    author="Napster",
    url="https://www.neuralcoders.com",
    packages=["modules","modules"]
)

